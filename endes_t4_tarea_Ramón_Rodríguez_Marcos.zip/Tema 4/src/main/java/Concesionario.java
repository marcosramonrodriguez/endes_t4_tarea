import java.util.ArrayList;

/**
 * La clase Concesionario representa al lugar donde se pueden almacenar y gestionar autos
 *
 * @autor Marcos
 */
public class Concesionario {

    private ArrayList<Auto> autos; // La lista de los autos en el concesionario

    /**
     * Constructor para la creacion de un objeto Concesionario
     *
     * @autor Marcos
     */
    public Concesionario() {
        autos = new ArrayList<>();
    }

    /**
     * Agregar un auto al inventario del concesionario.
     *
     * @param auto El auto que vamos a agregar
     * @autor Marcos
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

    /**
     * Obtenemos una lista de los autos en el inventario del concesionario
     *
     * @return Una lista de autos en el inventario del concesionario
     * @autor Marcos
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

    /**
     * Imprimimos los detalles de todos los autos en el inventario del concesionario
     *
     * @autor Marcos
     */
    public void imprimirAutos() {
        for (Auto auto : autos) {
            System.out.println(auto);
        }
    }
}