/**
 * La clase Auto representa un vehículo con atributos como la marca y su modelo
 *
 * @autor Marcos
 */
public class Auto {

    private String marca; // La marca del auto
    private String modelo; // El modelo del auto

    /**
     * Constructor para la creacion de un objeto Auto con la marca y modelo especificandolos
     *
     * @param marca La marca del auto
     * @param modelo El modelo del auto
     * @autor Marcos
     */
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * Obtenemos la marca del auto
     *
     * @return La marca del auto
     * @autor Marcos
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Establecemos la marca del auto
     *
     * @param marca La nueva marca del auto
     * @autor Marcos
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Obtenemos el modelo del auto
     *
     * @return El modelo del auto
     * @autor Marcos
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Establecemos el modelo del auto
     *
     * @param modelo El nuevo modelo del auto
     * @autor Marcos
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Devolvemos una representación en forma de cadena del objeto Auto
     *
     * @return Una cadena que representa el objeto Auto
     * @autor Marcos
     */
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + "]";
    }
}